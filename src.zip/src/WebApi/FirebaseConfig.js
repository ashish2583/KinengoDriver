// Import the functions you need from the SDKs you need
// import { initializeApp } from "firebase/app";
// import { getAnalytics } from "firebase/analytics";

export const firebaseConfig = {
  apiKey: "AIzaSyACzgsZq8gI9VFkOw_fwLJdmezbc4iUxiM",
  authDomain: "compact-scene-324005.firebaseapp.com",
  databaseURL: "https://compact-scene-324005-default-rtdb.firebaseio.com",
  projectId: "compact-scene-324005",
  storageBucket: "compact-scene-324005.appspot.com",
  messagingSenderId: "113857152783",
  appId: "1:113857152783:web:764e94107979021e97a07a",
  measurementId: "G-4VKMQM6GV8"
};


// const app = initializeApp(firebaseConfig);
// const analytics = getAnalytics(app);