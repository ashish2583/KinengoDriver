export const GoogleApiKey = 'AIzaSyDBeSqFBgF2V-IXmJdeTM3ZZUYG_5nKm-g'
export const reactnativecardscan='otN5EJwBHgQRUAYzasnciAd1Q5sJbBkY'
export const Stripe_public_key= 'pk_test_4sjCZIFhfIeMDj3bpJsFapZf' 
export const Stripe_secret_key= 'sk_test_dV9SzRCmNPMKr33sBazUC54G'