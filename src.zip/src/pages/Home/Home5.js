import React, { useEffect, useState } from 'react';
import {View,Image,Text,StyleSheet,SafeAreaView,TextInput,FlatList, TouchableOpacity,Platform, Alert, PermissionsAndroid, ScrollView, Linking} from 'react-native';
import {Mycolors,dimensions} from '../../utility/Mycolors';

const Home5 = (props) => {
   
    return(
    <SafeAreaView style={styles.container}>
    
    </SafeAreaView>
     );
  }
const styles = StyleSheet.create({

  container: {
    flex: 1,  
    backgroundColor:Mycolors.BG_COLOR
  },
  
  
});
export default Home5