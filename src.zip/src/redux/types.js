export const LOADING = "LOADING";

export const RESPONSE_ERROR = "RESPONSE_ERROR";

export const LOGOUT_USER = "LOGOUT_USER";

export const SAVE_USER_RESULTS = "SAVE_USER_RESULTS";  

export const SAVE_CORP_USER_RESULTS = "SAVE_CORP_USER_RESULTS";

export const TOKEN = "TOKEN"; 

export const CURRENTADD = "CURRENTADD";

export const STARTADD = "STARTADD";

export const DESTNATIONADD = "DESTNATIONADD";

export const CURRENTPOS = "CURRENTPOS";

export const STARTPOS = "STARTPOS";

export const DESTNATIONPOS = "DESTNATIONPOS";

export const NETINFOS = "NETINFOS";

export const NOTIFY = "NOTIFY";

export const NOTIFICATIONDATA = "NOTIFICATIONDATA";

export const DEVICETOKEN = "DEVICETOKEN";

export const MESSAGECOUNT = "MESSAGECOUNT";

export const BIDAMOUNT = "BIDAMOUNT";

export const USERTYPE = "USERTYPE"; NOOFCAR

export const NOOFCAR = "NOOFCAR";

export const NOOFDRV = "NOOFDRV";

export const SELECTEDDRVTAB = "SELECTEDDRVTAB";

export const SELECTEDCARTAB = "SELECTEDCARTAB";   

export const VEHICLEID = "VEHICLEID";

export const DRVID = "DRVID";  

export const DASHDATA = "DASHDATA";

export const AUTHTOKEN = "AUTHTOKEN";

